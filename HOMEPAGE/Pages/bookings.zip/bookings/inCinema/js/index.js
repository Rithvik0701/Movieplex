const pantherbutton = document.querySelector(".panther");
const superManButton = document.querySelector(".superman");



pantherbutton.addEventListener("click", (event) => {
    location.href = "../Movie-Seat-Booking-main/index.html";

});

superManButton.addEventListener("click", (event) => {
    location.href = "../Movie-Seat-Booking-main/index.html";

});

